"""PLAVE Weverse translation workstation."""
